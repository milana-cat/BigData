import pandas as pd
import os
from sklearn.model_selection import train_test_split
from lightautoml.automl.presets.tabular_presets import TabularAutoML
import time

def analyze_wine_data():
    current_dir = os.path.dirname(__file__)
    file_path = os.path.join(current_dir, "WineQT.csv")
    data = pd.read_csv(file_path)

    # Классификация: Квантильная разбивка по sulphates
    data['sulphates_class'] = pd.qcut(data['sulphates'], q=3, labels=["Low", "Medium", "High"])

    # КЛАССИФИКАЦИЯ
    print("\n=== КЛАССИФИКАЦИЯ ===")
    classification_data = data[['pH', 'quality', 'sulphates_class']].copy()
    X_class = classification_data.drop(columns='sulphates_class')
    y_class = classification_data['sulphates_class']

    X_train_class, X_test_class, y_train_class, y_test_class = train_test_split(X_class, y_class, test_size=0.2, random_state=42)

    automl_class = TabularAutoML(task='multiclass', timeout=60)
    start = time.time()
    oof_pred_class = automl_class.fit_predict(X_train_class, y_train_class)
    print("Время обучения классификации:", round(time.time() - start, 2), "сек")

    test_pred_class = automl_class.predict(X_test_class)
    print("Классификация завершена.")

    # РЕГРЕССИЯ
    print("\n=== РЕГРЕССИЯ ===")
    regression_data = data[['quality', 'sulphates']].copy()
    X_reg = regression_data.drop(columns='sulphates')
    y_reg = regression_data['sulphates']

    X_train_reg, X_test_reg, y_train_reg, y_test_reg = train_test_split(X_reg, y_reg, test_size=0.2, random_state=42)

    automl_reg = TabularAutoML(task='reg', timeout=60)
    start = time.time()
    oof_pred_reg = automl_reg.fit_predict(X_train_reg, y_train_reg)
    print("Время обучения регрессии:", round(time.time() - start, 2), "сек")

    test_pred_reg = automl_reg.predict(X_test_reg)
    print("Регрессия завершена.")

analyze_wine_data()
